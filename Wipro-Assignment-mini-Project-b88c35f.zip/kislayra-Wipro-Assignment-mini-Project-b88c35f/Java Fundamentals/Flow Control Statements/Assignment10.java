//Write a program to print numbers from 1 to 10 in a single row with one tab space.

public class Assignment10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 1; i <= 10; i++) {
			System.out.print(i+" ");
		}
	}

}
