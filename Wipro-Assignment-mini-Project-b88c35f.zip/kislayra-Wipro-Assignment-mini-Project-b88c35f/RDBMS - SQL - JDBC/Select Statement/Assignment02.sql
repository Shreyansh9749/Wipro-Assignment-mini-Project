SELECT employee_id, job_id, last_name, hire_date AS STARTDATE 
FROM employees;